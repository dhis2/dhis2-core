Ext.override(Ext.LoadMask, {
	onHide: function() {
		this.callParent();
	}
});
